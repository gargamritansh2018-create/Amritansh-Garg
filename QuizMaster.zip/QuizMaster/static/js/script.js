// GARG BANDHU Website JavaScript

// DOM Content Loaded Event
document.addEventListener('DOMContentLoaded', function() {
    initializeWebsite();
});

// Initialize all website functionality
function initializeWebsite() {
    setupNavigation();
    setupScrollAnimations();
    setupIntersectionObserver();
    console.log('GARG BANDHU website initialized successfully');
}

// Navigation functionality
function setupNavigation() {
    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                const offsetTop = targetSection.offsetTop - 80; // Account for fixed navbar
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
                
                // Update active nav link
                updateActiveNavLink(this);
                
                // Close mobile menu if open
                closeMobileMenu();
            }
        });
    });
    
    // Scroll event for navbar
    window.addEventListener('scroll', handleNavbarScroll);
}

// Handle navbar scroll effect
function handleNavbarScroll() {
    const navbar = document.getElementById('navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('navbar-scrolled');
    } else {
        navbar.classList.remove('navbar-scrolled');
    }
    
    // Update active nav link based on scroll position
    updateActiveNavOnScroll();
}

// Update active navigation link
function updateActiveNavLink(activeLink) {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.classList.remove('active');
    });
    activeLink.classList.add('active');
}

// Update active nav link on scroll
function updateActiveNavOnScroll() {
    const sections = document.querySelectorAll('section[id]');
    const scrollPos = window.scrollY + 100;
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.offsetHeight;
        const sectionId = section.getAttribute('id');
        
        if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
            const correspondingNavLink = document.querySelector(`.nav-link[href="#${sectionId}"]`);
            if (correspondingNavLink) {
                updateActiveNavLink(correspondingNavLink);
            }
        }
    });
}

// Mobile menu functionality
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobile-menu');
    const menuIcon = document.getElementById('mobile-menu-icon');
    
    if (mobileMenu.classList.contains('hidden')) {
        mobileMenu.classList.remove('hidden');
        menuIcon.classList.remove('fa-bars');
        menuIcon.classList.add('fa-times');
    } else {
        mobileMenu.classList.add('hidden');
        menuIcon.classList.remove('fa-times');
        menuIcon.classList.add('fa-bars');
    }
}

function closeMobileMenu() {
    const mobileMenu = document.getElementById('mobile-menu');
    const menuIcon = document.getElementById('mobile-menu-icon');
    
    mobileMenu.classList.add('hidden');
    menuIcon.classList.remove('fa-times');
    menuIcon.classList.add('fa-bars');
}

// Booking Modal functionality
function openBookingModal() {
    const modal = document.getElementById('bookingModal');
    modal.classList.remove('hidden');
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
    
    // Focus on first input
    setTimeout(() => {
        document.getElementById('customerName').focus();
    }, 300);
}

function closeBookingModal() {
    const modal = document.getElementById('bookingModal');
    modal.classList.add('hidden');
    modal.classList.remove('show');
    document.body.style.overflow = 'auto';
    
    // Reset form
    document.getElementById('bookingForm').reset();
    toggleOtherField(); // Hide other field if visible
}

// Handle material selection change
function toggleOtherField() {
    const materialSelect = document.getElementById('materialSelection');
    const otherField = document.getElementById('otherMaterialField');
    const otherInput = document.getElementById('otherMaterial');
    
    if (materialSelect.value === 'Other') {
        otherField.classList.remove('hidden');
        otherInput.setAttribute('required', 'required');
    } else {
        otherField.classList.add('hidden');
        otherInput.removeAttribute('required');
        otherInput.value = '';
    }
}

// Handle booking form submission
function submitBooking(event) {
    event.preventDefault();
    
    // Get form data
    const formData = new FormData(event.target);
    const customerName = formData.get('customerName').trim();
    const phoneNumber = formData.get('phoneNumber').trim();
    const materialSelection = formData.get('materialSelection');
    const otherMaterial = formData.get('otherMaterial')?.trim() || '';
    const customerAddress = formData.get('customerAddress')?.trim() || '';
    
    // Validate required fields
    if (!customerName || !phoneNumber || !materialSelection) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }
    
    // Validate phone number (basic validation)
    if (!isValidPhoneNumber(phoneNumber)) {
        showNotification('Please enter a valid phone number', 'error');
        return;
    }
    
    // Determine the material text
    let materialText = materialSelection;
    if (materialSelection === 'Other' && otherMaterial) {
        materialText = otherMaterial;
    }
    
    // Generate WhatsApp message
    const whatsappMessage = generateWhatsAppMessage(customerName, phoneNumber, materialText, customerAddress);
    
    // Create WhatsApp URL with proper encoding
    const whatsappUrl = `https://wa.me/918839341845?text=${encodeURIComponent(whatsappMessage)}`;
    
    // Show loading state
    const submitButton = event.target.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Redirecting...';
    submitButton.disabled = true;
    
    // Debug: Log the URL to console
    console.log('WhatsApp URL:', whatsappUrl);
    
    // Try direct location change first, then fallback to window.open
    try {
        window.location.href = whatsappUrl;
    } catch (error) {
        console.log('Direct navigation failed, trying window.open:', error);
        window.open(whatsappUrl, '_blank');
    }
    
    // Reset button and close modal after a short delay
    setTimeout(() => {
        submitButton.innerHTML = originalText;
        submitButton.disabled = false;
        closeBookingModal();
        showNotification('Redirected to WhatsApp', 'success');
    }, 1500);
}

// Generate WhatsApp message
function generateWhatsAppMessage(name, phone, material, address) {
    let message = `🧱 *New Enquiry - GARG BANDHU*\n\n`;
    message += `👤 Name: ${name}\n`;
    message += `📱 Phone: ${phone}\n`;
    message += `🏗️ Material Required: ${material}\n`;
    
    if (address) {
        message += `📍 Address: ${address}\n`;
    }
    
    message += `\nHello, I want to place an enquiry/order. Please confirm availability.`;
    
    console.log('Generated message:', message);
    return message;
}

// Phone number validation
function isValidPhoneNumber(phone) {
    // Remove all non-digit characters
    const cleanPhone = phone.replace(/\D/g, '');
    
    // Check if it's a valid Indian mobile number (10 digits) or with country code (12 digits starting with 91)
    return /^[6-9]\d{9}$/.test(cleanPhone) || /^91[6-9]\d{9}$/.test(cleanPhone);
}

// Notification system
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm transition-all duration-300 transform translate-x-full`;
    
    // Set notification style based on type
    switch (type) {
        case 'success':
            notification.classList.add('bg-green-500', 'text-white');
            break;
        case 'error':
            notification.classList.add('bg-red-500', 'text-white');
            break;
        default:
            notification.classList.add('bg-blue-500', 'text-white');
    }
    
    // Set notification content
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info'} mr-2"></i>
            <span>${message}</span>
        </div>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.classList.remove('translate-x-full');
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Scroll animations
function setupScrollAnimations() {
    // Add animation classes to elements that should animate on scroll
    const animateElements = document.querySelectorAll('.fade-in-up, .fade-in-left, .fade-in-right');
    animateElements.forEach(element => {
        element.classList.add('animate-on-scroll');
    });
}

// Intersection Observer for scroll animations
function setupIntersectionObserver() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    // Observe all elements with animate-on-scroll class
    const animateElements = document.querySelectorAll('.animate-on-scroll');
    animateElements.forEach(element => {
        observer.observe(element);
    });
}

// Close modal when clicking outside
document.addEventListener('click', function(event) {
    const modal = document.getElementById('bookingModal');
    if (event.target === modal) {
        closeBookingModal();
    }
});

// Close modal on escape key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const modal = document.getElementById('bookingModal');
        if (!modal.classList.contains('hidden')) {
            closeBookingModal();
        }
    }
});

// Handle form input formatting
document.addEventListener('input', function(event) {
    // Format phone number input
    if (event.target.id === 'phoneNumber') {
        let value = event.target.value.replace(/\D/g, '');
        if (value.length > 10) {
            value = value.slice(0, 10);
        }
        event.target.value = value;
    }
});

// Performance optimization: Debounce scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Apply debouncing to scroll handler
const debouncedScrollHandler = debounce(handleNavbarScroll, 10);
window.removeEventListener('scroll', handleNavbarScroll);
window.addEventListener('scroll', debouncedScrollHandler);

// Service worker registration (for future PWA capabilities)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        // Service worker can be added in future updates
        console.log('Service Worker support detected');
    });
}

// Initialize lazy loading for images (if any are added in future)
function initializeLazyLoading() {
    const images = document.querySelectorAll('img[data-lazy]');
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.lazy;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// Call lazy loading initialization
initializeLazyLoading();

// Analytics tracking (placeholder for future implementation)
function trackEvent(eventName, eventData = {}) {
    console.log(`Event tracked: ${eventName}`, eventData);
    // Future: Integrate with Google Analytics or other tracking service
}

// Track important interactions
document.addEventListener('click', function(event) {
    // Track button clicks
    if (event.target.tagName === 'BUTTON' || event.target.closest('button')) {
        const button = event.target.closest('button') || event.target;
        trackEvent('button_click', {
            button_text: button.textContent.trim(),
            button_location: button.id || button.className
        });
    }
    
    // Track link clicks
    if (event.target.tagName === 'A' || event.target.closest('a')) {
        const link = event.target.closest('a') || event.target;
        trackEvent('link_click', {
            link_text: link.textContent.trim(),
            link_url: link.href
        });
    }
});

// Console welcome message
console.log('%c🧱 GARG BANDHU Website Loaded Successfully! 🏗️', 'color: #2A90E0; font-size: 16px; font-weight: bold;');
console.log('Supplying Strength. Building Dreams since 1987.');
